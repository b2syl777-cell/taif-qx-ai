# Taif QX AI ProGuard rules
