package com.taif.qxai.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111726)
val DarkSurfaceElevated = Color(0xFF182238)
val DarkBorder = Color(0xFF22304A)

val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)
val CyberCyan = Color(0xFF00E5FF)
val CyberYellow = Color(0xFFFFD600)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
