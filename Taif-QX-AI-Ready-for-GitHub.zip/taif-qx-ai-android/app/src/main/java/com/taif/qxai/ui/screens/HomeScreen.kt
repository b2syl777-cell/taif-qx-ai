package com.taif.qxai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taif.qxai.model.MarketType
import com.taif.qxai.ui.theme.*

@Composable
fun HomeScreen(
    hasOverlayPermission: Boolean,
    isProjectionRunning: Boolean,
    isFloatingRunning: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onRequestProjectionPermission: () -> Unit,
    onToggleFloatingService: () -> Unit
) {
    var selectedMarket by remember { mutableStateOf(MarketType.OTC) }
    var selectedTimeframe by remember { mutableStateOf("1M") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TAIF QX AI",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CyberCyan
                )
                Text(
                    text = "Quotex AI Dual-Core Scanner",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceElevated)
                    .border(1.dp, if (isFloatingRunning) NeonGreen else TextMuted, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isFloatingRunning) "ACTIVE OVER QUOTEX" else "IDLE",
                    color = if (isFloatingRunning) NeonGreen else TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Floating Service Master Control Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "FLOATING RADAR CONTROL",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )

                // Permission item 1: Overlay
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("1. Display Over Other Apps", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Required for floating button & laser scanner", color = TextSecondary, fontSize = 12.sp)
                    }
                    if (hasOverlayPermission) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Granted", tint = NeonGreen)
                    } else {
                        Button(
                            onClick = onRequestOverlayPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = DarkBackground)
                        ) {
                            Text("Grant")
                        }
                    }
                }

                Divider(color = DarkBorder)

                // Permission item 2: Screen Projection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("2. MediaProjection Screen Capture", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Allows one-tap real-time chart capture", color = TextSecondary, fontSize = 12.sp)
                    }
                    if (isProjectionRunning) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = NeonGreen)
                    } else {
                        Button(
                            onClick = onRequestProjectionPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = DarkBackground)
                        ) {
                            Text("Authorize")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Big Master Toggle
                Button(
                    onClick = onToggleFloatingService,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isFloatingRunning) NeonRed else NeonGreen,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isFloatingRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isFloatingRunning) "STOP FLOATING SCANNER" else "START FLOATING SCANNER",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Market & Timeframe Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "TARGET MARKET",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MarketType.values().forEach { market ->
                        FilterChip(
                            selected = selectedMarket == market,
                            onClick = { selectedMarket = market },
                            label = { Text(market.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan,
                                selectedLabelColor = DarkBackground
                            )
                        )
                    }
                }

                Text(
                    text = "EXPIRY TIMEFRAME",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("1M", "2M", "5M").forEach { tf ->
                        FilterChip(
                            selected = selectedTimeframe == tf,
                            onClick = { selectedTimeframe = tf },
                            label = { Text(tf, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonGreen,
                                selectedLabelColor = DarkBackground
                            )
                        )
                    }
                }
            }
        }

        // AI Architecture Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("DUAL AI ENGINE STATUS", style = MaterialTheme.typography.titleLarge, color = CyberCyan)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(NeonGreen))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Gemini 3.8 Flash Vision: Multimodal Candle & Level Analysis", color = TextPrimary, fontSize = 13.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(CyberCyan))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Local CV Engine: Pixel Momentum, RSI & Bollinger Filter", color = TextPrimary, fontSize = 13.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(CyberYellow))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Strict Consensus: DIVERGENCE triggers NO SIGNAL protection", color = TextPrimary, fontSize = 13.sp)
                }
            }
        }
    }
}
