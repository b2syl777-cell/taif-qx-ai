package com.taif.qxai.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taif.qxai.ui.theme.*

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("taif_qx_prefs", Context.MODE_PRIVATE) }

    var apiKey by remember { mutableStateOf(prefs.getString("gemini_api_key", "") ?: "") }
    var minConfidence by remember { mutableFloatStateOf(prefs.getFloat("min_confidence", 75f)) }
    var hapticFeedback by remember { mutableStateOf(prefs.getBoolean("haptic_feedback", true)) }
    var soundAlerts by remember { mutableStateOf(prefs.getBoolean("sound_alerts", true)) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SCANNER & AI SETTINGS",
            style = MaterialTheme.typography.headlineMedium,
            color = CyberCyan
        )
        Text(
            text = "Configure Gemini API connection, sensitivity and feedback",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        // Gemini AI Configuration Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "GEMINI 3.8 FLASH API CONFIGURATION",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonGreen
                )
                Text(
                    text = "Powers multimodal visual candle recognition and support/resistance analysis. Can also run seamlessly via Local CV fallback if offline.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = DarkBorder
                    )
                )

                Button(
                    onClick = {
                        prefs.edit().putString("gemini_api_key", apiKey.trim()).apply()
                        Toast.makeText(context, "API Key Saved Successfully!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = DarkBackground),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Save API Key", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Trading Risk Filters
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "ACCURACY & SIGNAL FILTERS",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )

                Text(
                    text = "Minimum Confidence Threshold: ${minConfidence.toInt()}%",
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                Slider(
                    value = minConfidence,
                    onValueChange = {
                        minConfidence = it
                        prefs.edit().putFloat("min_confidence", it).apply()
                    },
                    valueRange = 60f..95f,
                    steps = 7,
                    colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                )
                Text(
                    text = "Signals with confidence below ${minConfidence.toInt()}% automatically return NO SIGNAL.",
                    color = TextMuted,
                    fontSize = 11.sp
                )

                Divider(color = DarkBorder)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Haptic Vibration Pulse", color = TextPrimary)
                        Text("Distinct vibration patterns for CALL / PUT / NO_SIGNAL", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = hapticFeedback,
                        onCheckedChange = {
                            hapticFeedback = it
                            prefs.edit().putBoolean("haptic_feedback", it).apply()
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Laser Audio Tone", color = TextPrimary)
                        Text("Sound frequency feedback when laser sweep initiates", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = soundAlerts,
                        onCheckedChange = {
                            soundAlerts = it
                            prefs.edit().putBoolean("sound_alerts", it).apply()
                        }
                    )
                }
            }
        }

        // App Info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ABOUT TAIF QX AI", color = CyberCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Text("Version: 1.0.0 (Release Build)", color = TextSecondary, fontSize = 12.sp)
                Text("Package: com.taif.qxai", color = TextSecondary, fontSize = 12.sp)
                Text("Framework: Jetpack Compose + MediaProjection + WindowManager", color = TextSecondary, fontSize = 12.sp)
                Text("Target Platforms: Quotex, Pocket Option, Olymp Trade, Binomo", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}
