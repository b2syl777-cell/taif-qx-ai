package com.taif.qxai.model

enum class SignalType {
    CALL,
    PUT,
    NO_SIGNAL
}

enum class MarketType(val label: String) {
    FOREX("Forex"),
    OTC("Quotex OTC"),
    CRYPTO("Crypto"),
    BINARY("Binary Options")
}

data class IndicatorData(
    val emaTrend: String = "NEUTRAL",
    val rsiValue: Double = 50.0,
    val macdCondition: String = "NEUTRAL",
    val bollingerPosition: String = "INSIDE"
)

data class MartingalePlan(
    val step: Int = 0,
    val advice: String = "Primary Entry",
    val multiplier: Double = 2.2,
    val recommendedAmount: Double = 10.0
)

data class KeyLevels(
    val support: String = "N/A",
    val resistance: String = "N/A"
)

data class SingleAnalysis(
    val source: String, // "Gemini AI" or "Local AI"
    val signal: SignalType,
    val confidence: Int,
    val patterns: List<String>,
    val summary: String,
    val indicators: IndicatorData = IndicatorData()
)

data class FinalTradeSignal(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val finalSignal: SignalType,
    val confidence: Int,
    val marketType: MarketType,
    val pair: String,
    val timeframe: String,
    val geminiAnalysis: SingleAnalysis?,
    val localAnalysis: SingleAnalysis,
    val patterns: List<String>,
    val mtgPlan: MartingalePlan,
    val technicalSummary: String,
    val keyLevels: KeyLevels = KeyLevels()
)
