package com.taif.qxai.ai

import com.taif.qxai.model.*

object DualEngineConsensus {

    fun combineResults(
        local: SingleAnalysis,
        gemini: SingleAnalysis?,
        marketType: MarketType,
        pair: String,
        timeframe: String
    ): FinalTradeSignal {
        val allPatterns = mutableSetOf<String>()
        allPatterns.addAll(local.patterns)
        gemini?.patterns?.let { allPatterns.addAll(it) }

        // If Gemini is available
        val (finalSignal, finalConfidence, mtgPlan, summary) = if (gemini != null) {
            when {
                // Strong consensus: Both agree on CALL
                local.signal == SignalType.CALL && gemini.signal == SignalType.CALL -> {
                    val avgConf = ((local.confidence + gemini.confidence) / 2.0).toInt().coerceIn(78, 97)
                    val mtg = MartingalePlan(
                        step = 0,
                        advice = "Strong High-Probability CALL. Execute at candle opening. MTG 1 standby only.",
                        multiplier = 2.2,
                        recommendedAmount = 10.0
                    )
                    val summ = "Full Consensus (CALL): Gemini Vision (${gemini.confidence}%) and Local CV (${local.confidence}%) confirmed upward momentum with bullish candle action."
                    Tuple4(SignalType.CALL, avgConf, mtg, summ)
                }

                // Strong consensus: Both agree on PUT
                local.signal == SignalType.PUT && gemini.signal == SignalType.PUT -> {
                    val avgConf = ((local.confidence + gemini.confidence) / 2.0).toInt().coerceIn(78, 97)
                    val mtg = MartingalePlan(
                        step = 0,
                        advice = "Strong High-Probability PUT. Execute at candle opening. MTG 1 standby only.",
                        multiplier = 2.2,
                        recommendedAmount = 10.0
                    )
                    val summ = "Full Consensus (PUT): Gemini Vision (${gemini.confidence}%) and Local CV (${local.confidence}%) confirmed downward rejection with bearish candle action."
                    Tuple4(SignalType.PUT, avgConf, mtg, summ)
                }

                // Gemini high confidence (>= 85%) while Local is neutral
                gemini.confidence >= 85 && gemini.signal != SignalType.NO_SIGNAL && local.signal == SignalType.NO_SIGNAL -> {
                    val conf = (gemini.confidence * 0.92).toInt()
                    val mtg = MartingalePlan(
                        step = 1,
                        advice = "Gemini High-Conviction ${gemini.signal}. Moderate local confirmation; keep MTG 1 ready.",
                        multiplier = 2.2,
                        recommendedAmount = 10.0
                    )
                    val summ = "Gemini Dominant Signal (${gemini.signal} @ ${gemini.confidence}%). Local CV detected consolidation, so use strict MTG 1 safety buffer."
                    Tuple4(gemini.signal, conf, mtg, summ)
                }

                // Local high confidence (>= 85%) while Gemini is neutral
                local.confidence >= 85 && local.signal != SignalType.NO_SIGNAL && gemini.signal == SignalType.NO_SIGNAL -> {
                    val conf = (local.confidence * 0.90).toInt()
                    val mtg = MartingalePlan(
                        step = 1,
                        advice = "Local CV High-Conviction ${local.signal}. Keep MTG 1 ready.",
                        multiplier = 2.2,
                        recommendedAmount = 10.0
                    )
                    val summ = "Local CV Dominant Signal (${local.signal} @ ${local.confidence}%). Volume/wick patterns heavily indicate directional break."
                    Tuple4(local.signal, conf, mtg, summ)
                }

                // Divergence (One says CALL, one says PUT) or both NO_SIGNAL -> Absolute NO_SIGNAL safety protection
                else -> {
                    val mtg = MartingalePlan(
                        step = 0,
                        advice = "NO TRADE. Conflict between AI models or low edge. Wait for next candle cycle.",
                        multiplier = 0.0,
                        recommendedAmount = 0.0
                    )
                    val reason = if (local.signal != gemini.signal && local.signal != SignalType.NO_SIGNAL && gemini.signal != SignalType.NO_SIGNAL) {
                        "DIVERGENCE: Gemini predicts ${gemini.signal} while Local CV predicts ${local.signal}. Capital protection triggered."
                    } else {
                        "UNCERTAIN MARKET: Low directional conviction detected across both engines. Do not trade."
                    }
                    Tuple4(SignalType.NO_SIGNAL, 35, mtg, reason)
                }
            }
        } else {
            // Local AI only fallback
            if (local.signal != SignalType.NO_SIGNAL && local.confidence >= 75) {
                val mtg = MartingalePlan(
                    step = 0,
                    advice = "Local CV Clean Entry. Keep MTG 1 ready.",
                    multiplier = 2.2,
                    recommendedAmount = 10.0
                )
                Tuple4(local.signal, local.confidence, mtg, local.summary)
            } else {
                val mtg = MartingalePlan(
                    step = 0,
                    advice = "NO TRADE. Sideways or uncertain action.",
                    multiplier = 0.0,
                    recommendedAmount = 0.0
                )
                Tuple4(SignalType.NO_SIGNAL, 40, mtg, "Local AI detected low edge / market consolidation.")
            }
        }

        return FinalTradeSignal(
            finalSignal = finalSignal,
            confidence = finalConfidence,
            marketType = marketType,
            pair = pair,
            timeframe = timeframe,
            geminiAnalysis = gemini,
            localAnalysis = local,
            patterns = allPatterns.toList(),
            mtgPlan = mtgPlan,
            technicalSummary = summary,
            keyLevels = KeyLevels(
                support = "Dynamic S1 Zone",
                resistance = "Dynamic R1 Zone"
            )
        )
    }

    private data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
}
