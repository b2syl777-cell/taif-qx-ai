package com.taif.qxai.ai

import android.graphics.Bitmap
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.taif.qxai.model.IndicatorData
import com.taif.qxai.model.SignalType
import com.taif.qxai.model.SingleAnalysis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiAnalysisRepository(private val apiKeyProvider: () -> String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    suspend fun analyzeChartImage(
        bitmap: Bitmap,
        marketType: String = "OTC",
        pair: String = "EUR/USD (OTC)",
        timeframe: String = "1M"
    ): Result<SingleAnalysis> = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(Exception("Gemini API Key is not set. Please configure in Settings."))
        }

        try {
            // Compress bitmap to PNG byte array
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

            val prompt = """
                You are Taif QX AI, high-precision Quotex / Binary Options trading analyzer.
                Examine this chart for:
                - Market: $marketType
                - Asset: $pair
                - Timeframe: $timeframe
                
                Inspect candlestick patterns (Engulfing, Pinbar/Hammer, Doji, Star, Soldiers),
                trend indicators (EMA 9/21/50, RSI 14, MACD, Bollinger Bands), and support/resistance.
                
                Return JSON only in this exact format:
                {
                  "signal": "CALL" | "PUT" | "NO_SIGNAL",
                  "confidence": 0-100,
                  "patterns": ["pattern1", "pattern2"],
                  "summary": "concise technical reasoning",
                  "emaTrend": "BULLISH" | "BEARISH" | "NEUTRAL",
                  "rsiValue": 45.5,
                  "macdCondition": "BULLISH_CROSS" | "BEARISH_CROSS" | "NEUTRAL",
                  "bollingerPosition": "UPPER_BAND" | "LOWER_BAND" | "MIDDLE"
                }
            """.trimIndent()

            val requestJson = JsonObject().apply {
                val contentsArray = com.google.gson.JsonArray().apply {
                    val contentObj = JsonObject().apply {
                        val partsArray = com.google.gson.JsonArray().apply {
                            val imagePart = JsonObject().apply {
                                val inlineData = JsonObject().apply {
                                    addProperty("mimeType", "image/jpeg")
                                    addProperty("data", base64Image)
                                }
                                add("inlineData", inlineData)
                            }
                            val textPart = JsonObject().apply {
                                addProperty("text", prompt)
                            }
                            add(imagePart)
                            add(textPart)
                        }
                        add("parts", partsArray)
                    }
                    add(contentObj)
                }
                add("contents", contentsArray)

                val generationConfig = JsonObject().apply {
                    addProperty("responseMimeType", "application/json")
                }
                add("generationConfig", generationConfig)
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(url)
                .addHeader("User-Agent", "aistudio-build")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                return@withContext Result.failure(Exception("Gemini API Error (${response.code}): $errorBody"))
            }

            val responseBody = response.body?.string() ?: ""
            val jsonRoot = gson.fromJson(responseBody, JsonObject::class.java)
            val candidates = jsonRoot.getAsJsonArray("candidates")
            if (candidates == null || candidates.size() == 0) {
                return@withContext Result.failure(Exception("No analysis generated from Gemini model."))
            }

            val textOutput = candidates[0].asJsonObject
                .getAsJsonObject("content")
                .getAsJsonArray("parts")[0].asJsonObject
                .get("text").asString

            val parsedOutput = gson.fromJson(textOutput, JsonObject::class.java)

            val rawSignal = parsedOutput.get("signal")?.asString?.uppercase() ?: "NO_SIGNAL"
            val signal = when (rawSignal) {
                "CALL" -> SignalType.CALL
                "PUT" -> SignalType.PUT
                else -> SignalType.NO_SIGNAL
            }

            val confidence = parsedOutput.get("confidence")?.asInt ?: 50
            val patterns = mutableListOf<String>()
            parsedOutput.getAsJsonArray("patterns")?.forEach {
                patterns.add(it.asString)
            }
            val summary = parsedOutput.get("summary")?.asString ?: "Analysis completed by Gemini AI"

            val emaTrend = parsedOutput.get("emaTrend")?.asString ?: "NEUTRAL"
            val rsiValue = parsedOutput.get("rsiValue")?.asDouble ?: 50.0
            val macdCondition = parsedOutput.get("macdCondition")?.asString ?: "NEUTRAL"
            val bollingerPosition = parsedOutput.get("bollingerPosition")?.asString ?: "INSIDE"

            Result.success(
                SingleAnalysis(
                    source = "Gemini AI",
                    signal = signal,
                    confidence = confidence,
                    patterns = patterns,
                    summary = summary,
                    indicators = IndicatorData(
                        emaTrend = emaTrend,
                        rsiValue = rsiValue,
                        macdCondition = macdCondition,
                        bollingerPosition = bollingerPosition
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
