package com.taif.qxai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taif.qxai.ui.theme.*

@Composable
fun MtgCalculatorScreen() {
    var balance by remember { mutableStateOf("500") }
    var baseStake by remember { mutableStateOf("10") }
    var payoutPercent by remember { mutableFloatStateOf(87f) }
    var multiplier by remember { mutableFloatStateOf(2.2f) }

    val base = baseStake.toDoubleOrNull() ?: 10.0
    val totalBal = balance.toDoubleOrNull() ?: 500.0
    val payoutRate = payoutPercent / 100.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "MARTINGALE (MTG) CALCULATOR",
            style = MaterialTheme.typography.headlineMedium,
            color = CyberCyan
        )
        Text(
            text = "Risk Management & Profit Recovery Matrix for Quotex",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        // Inputs Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = balance,
                    onValueChange = { balance = it },
                    label = { Text("Account Balance ($)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = DarkBorder
                    )
                )

                OutlinedTextField(
                    value = baseStake,
                    onValueChange = { baseStake = it },
                    label = { Text("Initial Stake / Base Bet ($)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = DarkBorder
                    )
                )

                Text(
                    text = "Quotex Asset Payout: ${payoutPercent.toInt()}%",
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                Slider(
                    value = payoutPercent,
                    onValueChange = { payoutPercent = it },
                    valueRange = 70f..95f,
                    steps = 24,
                    colors = SliderDefaults.colors(
                        thumbColor = CyberCyan,
                        activeTrackColor = CyberCyan
                    )
                )

                Text(
                    text = "MTG Multiplier: ${String.format("%.2f", multiplier)}x",
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                Slider(
                    value = multiplier,
                    onValueChange = { multiplier = it },
                    valueRange = 2.0f..2.5f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonGreen,
                        activeTrackColor = NeonGreen
                    )
                )
            }
        }

        // Calculation Matrix Table
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "STEP-BY-STEP MTG SCHEDULE",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonGreen
                )

                var cumCost = 0.0
                for (step in 0..3) {
                    val bet = if (step == 0) base else base * Math.pow(multiplier.toDouble(), step.toDouble())
                    cumCost += bet
                    val winReturn = bet * (1 + payoutRate)
                    val netProfit = winReturn - cumCost
                    val isSafe = cumCost <= totalBal

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSurfaceElevated, RoundedCornerShape(8.dp))
                            .border(1.dp, if (isSafe) DarkBorder else NeonRed, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (step == 0) "Step 0 (Primary)" else "Step $step (MTG $step)",
                                fontWeight = FontWeight.Bold,
                                color = if (step == 0) CyberCyan else NeonGreen,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Bet: $${String.format("%.2f", bet)} | Total: $${String.format("%.2f", cumCost)}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+$${String.format("%.2f", netProfit)}",
                                color = if (netProfit > 0) NeonGreen else NeonRed,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (isSafe) "Safe (Bal OK)" else "HIGH RISK",
                                color = if (isSafe) TextMuted else NeonRed,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
