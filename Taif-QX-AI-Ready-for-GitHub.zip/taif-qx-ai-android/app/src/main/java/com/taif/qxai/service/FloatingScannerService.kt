package com.taif.qxai.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.taif.qxai.R
import com.taif.qxai.ai.DualEngineConsensus
import com.taif.qxai.ai.GeminiAnalysisRepository
import com.taif.qxai.ai.LocalChartAnalyzer
import com.taif.qxai.model.FinalTradeSignal
import com.taif.qxai.model.MarketType
import com.taif.qxai.model.SignalType
import kotlinx.coroutines.*

class FloatingScannerService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingButtonView: View? = null
    private var laserScanOverlayView: View? = null
    private var resultCardView: View? = null

    private var screenCaptureService: ScreenCaptureService? = null
    private var isBound = false
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as ScreenCaptureService.LocalBinder
            screenCaptureService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            screenCaptureService = null
            isBound = false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        bindService(
            Intent(this, ScreenCaptureService::class.java),
            connection,
            Context.BIND_AUTO_CREATE
        )
        initFloatingButton()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingButton() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 450
        }

        // Custom Floating Pill View
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            val density = resources.displayMetrics.density
            val size = (64 * density).toInt()

            val circle = ImageView(this@FloatingScannerService).apply {
                layoutParams = FrameLayout.LayoutParams(size, size).apply {
                    gravity = Gravity.CENTER
                }
                // Cyber dark pill with glowing cyan border
                val drawable = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.parseColor("#0F1626"))
                    setStroke((3 * density).toInt(), Color.parseColor("#00E5FF"))
                }
                background = drawable
                setImageResource(android.R.drawable.ic_menu_camera)
                setColorFilter(Color.parseColor("#00E5FF"))
                setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt())
            }
            addView(circle)
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        frame.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) {
                        isDragging = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(frame, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        onScanTriggered()
                    }
                    true
                }
                else -> false
            }
        }

        floatingButtonView = frame
        windowManager.addView(floatingButtonView, params)
    }

    private fun onScanTriggered() {
        showLaserScanAnimation {
            captureAndProcess()
        }
    }

    private fun showLaserScanAnimation(onFinished: () -> Unit) {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        val laserView = LaserCanvasView(this)
        laserScanOverlayView = laserView
        windowManager.addView(laserView, overlayParams)

        // Animate laser line from top to bottom
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            addUpdateListener { anim ->
                laserView.laserProgress = anim.animatedValue as Float
                laserView.invalidate()
            }
        }

        animator.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                laserScanOverlayView?.let {
                    try {
                        windowManager.removeView(it)
                    } catch (e: Exception) {
                        // ignore
                    }
                    laserScanOverlayView = null
                }
                onFinished()
            }
        })

        animator.start()
    }

    private fun captureAndProcess() {
        val bitmap = screenCaptureService?.captureCurrentScreen()
        if (bitmap == null) {
            showSimpleResult("CAPTURE FAILED", "MediaProjection was not ready. Re-enable in Taif QX AI app.", Color.parseColor("#FF1744"))
            return
        }

        serviceScope.launch {
            // Step 1: Run Local AI
            val localResult = withContext(Dispatchers.Default) {
                LocalChartAnalyzer.analyzeBitmap(bitmap)
            }

            // Step 2: Run Gemini Vision AI
            val sharedPrefs = getSharedPreferences("taif_qx_prefs", Context.MODE_PRIVATE)
            val apiKey = sharedPrefs.getString("gemini_api_key", "") ?: ""
            val geminiRepo = GeminiAnalysisRepository { apiKey }

            val geminiResult = withContext(Dispatchers.IO) {
                geminiRepo.analyzeChartImage(bitmap, "OTC", "EUR/USD (OTC)", "1M").getOrNull()
            }

            // Step 3: Combine with Dual Consensus
            val finalSignal = DualEngineConsensus.combineResults(
                local = localResult,
                gemini = geminiResult,
                marketType = MarketType.OTC,
                pair = "EUR/USD (OTC)",
                timeframe = "1M"
            )

            // Step 4: Haptic Vibration Feedback
            triggerHaptic(finalSignal.finalSignal)

            // Step 5: Render Floating HUD Result Card over Quotex
            showResultCard(finalSignal)
        }
    }

    private fun triggerHaptic(signal: SignalType) {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (signal) {
                SignalType.CALL -> {
                    // Double energetic buzz
                    vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 200), -1))
                }
                SignalType.PUT -> {
                    // Triple distinct buzz
                    vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 100, 70, 100, 70, 180), -1))
                }
                SignalType.NO_SIGNAL -> {
                    // Single flat buzz
                    vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            }
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(200)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showResultCard(signal: FinalTradeSignal) {
        // Remove existing result card if active
        resultCardView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
            resultCardView = null
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val density = resources.displayMetrics.density
        val cardParams = WindowManager.LayoutParams(
            (320 * density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
            y = (90 * density).toInt()
        }

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * density).toInt()
            setPadding(pad, pad, pad, pad)

            // Card background: deep dark cyber card with glowing colored border
            val borderColor = when (signal.finalSignal) {
                SignalType.CALL -> Color.parseColor("#00E676")
                SignalType.PUT -> Color.parseColor("#FF1744")
                SignalType.NO_SIGNAL -> Color.parseColor("#FFD600")
            }

            val bg = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#101726"))
                cornerRadius = 18 * density
                setStroke((2 * density).toInt(), borderColor)
            }
            background = bg

            // Header Row: App badge & Close
            val headerRow = LinearLayout(this@FloatingScannerService).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 1f
            }
            val titleView = TextView(this@FloatingScannerService).apply {
                text = "TAIF QX AI • ${signal.pair}"
                setTextColor(Color.parseColor("#8E9DB2"))
                textSize = 12f
                typeface = Typeface.MONOSPACE
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val closeBtn = TextView(this@FloatingScannerService).apply {
                text = "✕"
                setTextColor(Color.WHITE)
                textSize = 16f
                setOnClickListener {
                    resultCardView?.let {
                        try { windowManager.removeView(it) } catch (e: Exception) {}
                        resultCardView = null
                    }
                }
            }
            headerRow.addView(titleView)
            headerRow.addView(closeBtn)
            addView(headerRow)

            // Signal Badge (Big CALL / PUT / NO SIGNAL)
            val signalText = TextView(this@FloatingScannerService).apply {
                text = when (signal.finalSignal) {
                    SignalType.CALL -> "▲ CALL (${signal.confidence}%)"
                    SignalType.PUT -> "▼ PUT (${signal.confidence}%)"
                    SignalType.NO_SIGNAL -> "⚠ NO SIGNAL (${signal.confidence}%)"
                }
                setTextColor(borderColor)
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(0, (8 * density).toInt(), 0, (4 * density).toInt())
            }
            addView(signalText)

            // MTG & Expiry row
            val subText = TextView(this@FloatingScannerService).apply {
                text = "Expiry: ${signal.timeframe} | MTG: Step ${signal.mtgPlan.step} (${signal.mtgPlan.advice})"
                setTextColor(Color.parseColor("#E0E6ED"))
                textSize = 12f
                typeface = Typeface.MONOSPACE
                gravity = Gravity.CENTER
            }
            addView(subText)

            // Detected Patterns
            if (signal.patterns.isNotEmpty()) {
                val patternsText = TextView(this@FloatingScannerService).apply {
                    text = "Patterns: ${signal.patterns.joinToString(" • ")}"
                    setTextColor(Color.parseColor("#00E5FF"))
                    textSize = 11f
                    setPadding(0, (8 * density).toInt(), 0, (4 * density).toInt())
                }
                addView(patternsText)
            }

            // Summary
            val summaryText = TextView(this@FloatingScannerService).apply {
                text = signal.technicalSummary
                setTextColor(Color.parseColor("#A3B3C8"))
                textSize = 11f
            }
            addView(summaryText)
        }

        resultCardView = rootLayout
        windowManager.addView(rootLayout, cardParams)

        // Auto dismiss after 12 seconds
        serviceScope.launch {
            delay(12000)
            resultCardView?.let {
                try { windowManager.removeView(it) } catch (e: Exception) {}
                resultCardView = null
            }
        }
    }

    private fun showSimpleResult(title: String, message: String, color: Int) {
        // Simple error or info notification card
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        floatingButtonView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
        }
        laserScanOverlayView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
        }
        resultCardView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
        }
    }

    // Laser scanning canvas view with glowing laser sweep line
    private class LaserCanvasView(context: Context) : View(context) {
        var laserProgress: Float = 0f

        private val laserPaint = Paint().apply {
            color = Color.parseColor("#00E5FF")
            strokeWidth = 6f
            style = Paint.Style.STROKE
            isAntiAlias = true
            setShadowLayer(16f, 0f, 0f, Color.parseColor("#00E5FF"))
        }

        private val glowPaint = Paint().apply {
            color = Color.argb(45, 0, 229, 255)
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val currentY = height * laserProgress
            // Draw laser sweep trail
            canvas.drawRect(0f, currentY - 60f, width.toFloat(), currentY, glowPaint)
            // Draw focused laser beam line
            canvas.drawLine(0f, currentY, width.toFloat(), currentY, laserPaint)
        }
    }
}
