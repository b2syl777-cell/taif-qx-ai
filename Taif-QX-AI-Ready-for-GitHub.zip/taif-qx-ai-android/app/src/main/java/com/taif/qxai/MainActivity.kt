package com.taif.qxai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.taif.qxai.service.FloatingScannerService
import com.taif.qxai.service.ScreenCaptureService
import com.taif.qxai.ui.screens.*
import com.taif.qxai.ui.theme.DarkBackground
import com.taif.qxai.ui.theme.DarkBorder
import com.taif.qxai.ui.theme.DarkSurface
import com.taif.qxai.ui.theme.TaifQXAITheme

enum class ScreenTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Scanner", Icons.Default.Radar),
    MTG("MTG Calc", Icons.Default.Calculate),
    HISTORY("History", Icons.Default.History),
    SETTINGS("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private var hasOverlayPermission by mutableStateOf(false)
    private var isProjectionRunning by mutableStateOf(false)
    private var isFloatingServiceRunning by mutableStateOf(false)

    // Screen Capture Permission Launcher
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startScreenCaptureService(result.resultCode, result.data!!)
            isProjectionRunning = true
            Toast.makeText(this, "Screen Capture permission granted!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Screen Capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkOverlayPermission()

        setContent {
            TaifQXAITheme {
                var selectedTab by remember { mutableStateOf(ScreenTab.DASHBOARD) }

                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = DarkSurface,
                            tonalElevation = 8.dp
                        ) {
                            ScreenTab.values().forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = { selectedTab = tab },
                                    icon = { Icon(tab.icon, contentDescription = tab.title) },
                                    label = { Text(tab.title) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                        indicatorColor = DarkBorder
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkBackground)
                            .padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            ScreenTab.DASHBOARD -> HomeScreen(
                                hasOverlayPermission = hasOverlayPermission,
                                isProjectionRunning = isProjectionRunning,
                                isFloatingRunning = isFloatingServiceRunning,
                                onRequestOverlayPermission = { requestOverlayPermission() },
                                onRequestProjectionPermission = { requestProjectionPermission() },
                                onToggleFloatingService = { toggleFloatingService() }
                            )
                            ScreenTab.MTG -> MtgCalculatorScreen()
                            ScreenTab.HISTORY -> HistoryScreen()
                            ScreenTab.SETTINGS -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkOverlayPermission()
    }

    private fun checkOverlayPermission() {
        hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun requestProjectionPermission() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun startScreenCaptureService(resultCode: Int, data: Intent) {
        val metrics = resources.displayMetrics
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_WIDTH, metrics.widthPixels)
            putExtra(ScreenCaptureService.EXTRA_HEIGHT, metrics.heightPixels)
            putExtra(ScreenCaptureService.EXTRA_DENSITY, metrics.densityDpi)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun toggleFloatingService() {
        if (!hasOverlayPermission) {
            requestOverlayPermission()
            return
        }
        if (!isProjectionRunning) {
            requestProjectionPermission()
            return
        }

        val serviceIntent = Intent(this, FloatingScannerService::class.java)
        if (isFloatingServiceRunning) {
            stopService(serviceIntent)
            isFloatingServiceRunning = false
            Toast.makeText(this, "Floating Scanner Stopped", Toast.LENGTH_SHORT).show()
        } else {
            startService(serviceIntent)
            isFloatingServiceRunning = true
            Toast.makeText(this, "Floating Scanner Activated over Quotex!", Toast.LENGTH_LONG).show()
        }
    }
}
