package com.taif.qxai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.taif.qxai.model.FinalTradeSignal
import com.taif.qxai.model.MarketType
import com.taif.qxai.model.MartingalePlan
import com.taif.qxai.model.SignalType
import com.taif.qxai.model.SingleAnalysis
import com.taif.qxai.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen() {
    val sampleHistory = remember {
        mutableStateListOf(
            FinalTradeSignal(
                finalSignal = SignalType.CALL,
                confidence = 94,
                marketType = MarketType.OTC,
                pair = "EUR/USD (OTC)",
                timeframe = "1M",
                geminiAnalysis = SingleAnalysis("Gemini AI", SignalType.CALL, 95, listOf("Bullish Engulfing", "EMA Golden Cross"), "Strong support bounce"),
                localAnalysis = SingleAnalysis("Local AI", SignalType.CALL, 93, listOf("Green Candle Dominance"), "Strong upward flow"),
                patterns = listOf("Bullish Engulfing", "EMA 9/21 Cross", "Support Rebound"),
                mtgPlan = MartingalePlan(0, "Direct Clean Entry"),
                technicalSummary = "Consensus achieved. Strong buyer volume and lower wick rejection."
            ),
            FinalTradeSignal(
                finalSignal = SignalType.PUT,
                confidence = 88,
                marketType = MarketType.OTC,
                pair = "GBP/JPY (OTC)",
                timeframe = "1M",
                geminiAnalysis = SingleAnalysis("Gemini AI", SignalType.PUT, 89, listOf("Evening Star"), "Resistance rejection"),
                localAnalysis = SingleAnalysis("Local AI", SignalType.PUT, 87, listOf("Red Candle Streak"), "Down momentum"),
                patterns = listOf("Evening Star", "RSI Overbought Piercing"),
                mtgPlan = MartingalePlan(0, "Direct Clean Entry"),
                technicalSummary = "Dual-engine confirmed resistance ceiling. RSI 74 rejection."
            ),
            FinalTradeSignal(
                finalSignal = SignalType.NO_SIGNAL,
                confidence = 42,
                marketType = MarketType.FOREX,
                pair = "USD/CAD",
                timeframe = "2M",
                geminiAnalysis = SingleAnalysis("Gemini AI", SignalType.PUT, 52, emptyList(), "Sideways channel"),
                localAnalysis = SingleAnalysis("Local AI", SignalType.CALL, 55, emptyList(), "Weak green tick"),
                patterns = listOf("Divergence / Consolidation"),
                mtgPlan = MartingalePlan(0, "NO TRADE"),
                technicalSummary = "Divergence between Gemini and Local CV. Safety protection prevented trade."
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SIGNAL LOG & ACCURACY",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CyberCyan
                )
                Text(
                    text = "Audit trail of captured Quotex charts",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            IconButton(onClick = { sampleHistory.clear() }) {
                Icon(Icons.Default.Delete, contentDescription = "Clear", tint = TextMuted)
            }
        }

        // Summary Stats Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatBox(label = "TOTAL SCANS", value = "${sampleHistory.size}", modifier = Modifier.weight(1f))
            StatBox(label = "AVG CONFIDENCE", value = "91%", modifier = Modifier.weight(1f))
            StatBox(label = "SAFE NO-SIGNAL", value = "1", modifier = Modifier.weight(1f))
        }

        // List of history items
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(sampleHistory) { item ->
                SignalHistoryCard(item)
            }
        }
    }
}

@Composable
fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text(value, color = CyberCyan, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun SignalHistoryCard(signal: FinalTradeSignal) {
    val borderColor = when (signal.finalSignal) {
        SignalType.CALL -> NeonGreen
        SignalType.PUT -> NeonRed
        SignalType.NO_SIGNAL -> CyberYellow
    }

    val timeString = remember(signal.timestamp) {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(signal.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${signal.pair} • ${signal.timeframe}",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Text(text = timeString, color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${signal.finalSignal.name} (${signal.confidence}%)",
                    color = borderColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "MTG: Step ${signal.mtgPlan.step}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            if (signal.patterns.isNotEmpty()) {
                Text(
                    text = signal.patterns.joinToString(" • "),
                    color = CyberCyan,
                    fontSize = 11.sp
                )
            }

            Text(
                text = signal.technicalSummary,
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
    }
}
