# Taif QX AI - Android Application
**Package:** `com.taif.qxai`  
**Target:** Android 8.0 (API 26) and newer (compile/target API 35)  
**Technology:** Kotlin, Jetpack Compose, Material3, MediaProjection, WindowManager Overlays

---

## 🚀 Key Features
1. **Advanced Floating Button**: Floats on top of Quotex, Pocket Option, Olymp Trade, or any broker app. Can be dragged anywhere on the screen with smooth physics.
2. **One-Tap Screen Capture**: Uses Android `MediaProjection` API via a dedicated foreground service (`ScreenCaptureService`) to capture the active candlestick chart instantly.
3. **Full-Screen Laser Scanning Animation**: Displays a cyber laser beam sweep across the chart during processing.
4. **Dual AI Consensus Engine**:
   - **Gemini 3.8 Flash Vision**: Multimodal visual analysis of candlestick wicks, bodies, trend lines, support/resistance, and broker indicators.
   - **Local CV Analyzer**: Instant on-device computer vision analyzing green/red pixel ratios, momentum slopes, RSI estimates, and Bollinger pierce.
5. **Strict Safety Rules**: If Gemini and Local AI diverge, or if confidence is below 75%, the engine strictly returns **NO SIGNAL** to protect trading capital.
6. **Martingale (MTG) Matrix**: Automatic Step 0 / Step 1 / Step 2 stake calculations based on Quotex payout percentages (70% - 95%).
7. **Signal Log & Accuracy Stats**: Complete history audit trail.

---

## 🛠 How to Build the APK

### Option A: 1-Click Automated GitHub Actions (No local Android Studio needed!)
1. Push this repository to your GitHub account:
   ```bash
   git init
   git add .
   git commit -m "Initial commit for Taif QX AI"
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/taif-qx-ai.git
   git push -u origin main
   ```
2. Navigate to the **Actions** tab on your GitHub repository.
3. The workflow `Build Taif QX AI APK` will automatically run and compile the APK.
4. Download the `Taif-QX-AI-debug-apk` artifact directly from the workflow run!

### Option B: Local Android Studio Build
1. Open **Android Studio** (Koala / Ladybug or newer with JDK 17).
2. Select **Open** and choose the extracted `taif-qx-ai-android` folder.
3. Allow Gradle to sync dependencies.
4. Go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. Once built, click **locate** to find `app-debug.apk` under `app/build/outputs/apk/debug/`.
6. Transfer `app-debug.apk` to your Android device via USB, Telegram, or Google Drive.

### Option C: Terminal / Command Line Build
```bash
gradle assembleDebug
```
The output APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 📱 Installation & Permissions Setup on Android

When opening the app for the first time:
1. **Display over other apps**:
   - Tap **"Grant"** in the app dashboard.
   - Android will open Special App Access settings. Toggle ON **"Allow display over other apps"** for **Taif QX AI**.
2. **Screen Capture (MediaProjection)**:
   - Tap **"Authorize"** in the app dashboard.
   - Android will prompt: *"Taif QX AI will start capturing everything displayed on your screen"*.
   - Tap **"Start now"** / **"While using the app"**.
3. **Launch Floating Scanner**:
   - Tap **"START FLOATING SCANNER"**.
   - Minimize Taif QX AI and open the **Quotex** app or browser chart.
   - The cyan circular floating button will stay visible over Quotex.
   - Tap the button whenever a candle opens to trigger the laser scan and receive instant CALL / PUT / NO SIGNAL HUD!
